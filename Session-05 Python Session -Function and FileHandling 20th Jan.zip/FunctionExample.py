#no argument no return 
def welcome():
    print('this is test function , this file contains wel,getnum, add, sub function ')
    print('end of function welcome')

#no argument with return
def getNum():
    a = int(input('enter data:'))
    b = int(input('enter data:'))
    return a,b

#argument with no return
def add(a,b):
    c =a+b
    print(c)
    
#argument with return
def sub(x,y):
    c = x-y
    return c


#argument with dynamic count of argument
def addnum(a,b=0,c=0,d=0):
    e =a+b+c+d
    print(e)

#dynanuc cout of argument
def mul(*a): #a type is tuple
    print(a)
    print(type(a))
    o =1
    for x in a:
        o*=x

    print(o)

#recussive : function which call or invoke itself i.e. called recussive
def fact(n):
    if n ==1:
        return n
    else:
        return n*fact(n-1)
    

#lambda expresion : anonyms function
tax = lambda n: n*.18

'''
def tax(n):
    n =n*.18
    return n
    
'''

    

#call to function
welcome()
welcome()

a,b =getNum()
print(a+b)

add(55,6)
add(666,4)

o = sub(55,66)
print(o)

addnum(11)
addnum(11,33)
addnum(11,33,55)
addnum(11,33,5,666)


mul(11,33,45)
mul(11,33,45,54,6,7,43,3,3,5,6,7,7,4)


o = fact(6)
print(o)

a = tax(1000)
print(a)


