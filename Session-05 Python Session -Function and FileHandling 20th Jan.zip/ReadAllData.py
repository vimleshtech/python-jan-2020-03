#read file

f = open(r'C:\Users\vkumar15\Desktop\Azure\out.txt','r') #a append , w write


#print(f)
#print(f.read())

#read first line
#print(f.readline())

#print(f.readlines())
d = f.readlines()

#get row count in file
#get word count
wc =0
for r in d:
    print(r)
    w = r.split(' ')
    wc = wc+ len(w)
    
    
print(len(d))

print(wc)












