#out is new file name , which will create

f = open(r'C:\Users\vkumar15\Desktop\Azure\out.txt','a') #a append , w write
#print(f)

for i in range(5):
    s = input('enter string ')
    f.write(s+'\n')
    
    #f.write('hi, this is test file\nend of file\n')

print('file is saved')

f.close()




