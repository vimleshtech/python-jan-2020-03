p = open(r'C:\Users\vkumar15\Desktop\Azure\prabh.txt','r') 
d = p.readlines()

'''wc =0
for r in d:
    print(r)
    w = r.split(' ') #list
    wc = wc+ len(w)

    #for word in w:
    #    if word =='is':
    #        print('is is found')
    if 'is' in w:
        print('is is found')
        
        
        


print(wc)
'''
