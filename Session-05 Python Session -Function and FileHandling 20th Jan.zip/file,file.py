f = open(r'C:\Users\vkumar15\Desktop\Azure\prabh.txt','r') 
p = open(r'C:\Users\vkumar15\Desktop\Azure\prabh2.txt','w')

p.write(f.read())
p.close()
f.close()



