s = input('enter string :')

print(len(s)-s.count(' '))



print(s.count(' ')+1)


