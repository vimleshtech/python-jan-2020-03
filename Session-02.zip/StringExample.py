s = input('enter string :')

print(s.upper())
print(s.lower())
print(s.title())
print(s.capitalize())
print(s.replace('i','a'))

print(len(s))

print(s.strip())
print(s.lstrip())
print(s.rstrip())

print(s.count('i'))


l = list(s)
print(l)

w = s.split(' ') #default seperator is space
print(w)


print(s[0]) #first char
print(s[0:4]) #first 4
print(s[-1])  #last one



if s.isdigit():
    print('number')


if s.isupper():
    print('upper')




if s.islower():
    print('lower')




if s.endswith("i"):
    print('ending with i')



    










