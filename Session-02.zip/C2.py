s = input('enter string :') #this IS test 
c = input('enter char :') #i 

l = list(s)
for ch in l:
    if ch.lower() == c.lower():
        print(ch.swapcase(),end='')
        
