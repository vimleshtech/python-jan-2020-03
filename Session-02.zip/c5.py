s = input('enter string :')

print(count('a','e','i','o','u'))
