s = input('enter string :')

print('space count ',s.count(' '))
print('tab count ',s.count('\t'))
print('new line count ',s.count('\n'))
