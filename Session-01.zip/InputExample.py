a = input('enter data ')
print(type(a))
print('you have entered  :',a)



##
a = input()
print(a)


###wap to get two numbers from user and show sum/addition
a = int(input('enter data '))   #type casting or type coversion
b = int(input('enter data '))



c =a+b
print(c)
