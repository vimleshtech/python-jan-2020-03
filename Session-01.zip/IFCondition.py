#if condition: take sales amt from user and show tax
sales = int(input('enter sales amt :'))

tax = 0

if sales>1000: #conditional statement
    tax = sales*.18 #18% on sales amt


#get total
total = sales+tax
print('total amt is :',total)






