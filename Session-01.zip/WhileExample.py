i =1

while i<10:    
    print(i)
    i=i+1


#print reverse
i =10
while i>0:
    print(i)
    i =i-1
#wap to get sum of all even and odd numbers between 1 to 100
se =0
so =0
i  =1
while i<=100:
    if i%2 ==0:
        se+=i
    else:
        so+=i

    i+=1

print('sum of all even ',se)
print('sum of all odd ',so)


#wap to print table of given number
t  = int(input('enter data :'))  #every input type is str 5

i =1
while i<=10:
    #print(t*i)
    print(t,'*',i,'=',t*i)
    i =i+1
    







        
    
      
    
