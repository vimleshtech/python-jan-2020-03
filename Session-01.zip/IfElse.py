#if else
sales = int(input('enter amt :'))

tax = 0
if sales>1000:
    tax = sales*.18 #18% tax if sales amt is less than 1000 otherwise 12% tax
else:
    tax = sales*.12



#total amt
total = sales+tax
print('total amt is :',total)

    
