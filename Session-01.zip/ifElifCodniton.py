#if elif elif elif .... else
amt = int(input('enter dales amt :'))

tax = 0

if amt>10000:
    tax = sales*.18
elif amt>5000:
    tax = sales*.12
elif amt>1000:
    tax = sales*.10
elif amt >500:
    tax = sales*.05
else:
    tax = sales*.02

total = amt + tax
print('total amt is ',total)
