import pandas as pd
import matplotlib.pyplot as plt

data ={'eid':[1,2,3,4,5,6,7,8,9,10],
       'name':['ayush','jatin','divya','mohit','monika','nitisha','raman','gaurav','kshitiz','nidhi'],
       'gender':['male','male','female','male','female','female','male','male','male','female'],
       'age':[21,22,23,41,25,36,47,38,49,41],
       'salary':[10000,20000,30000,40000,50000,60000,70000,80000,90000,100000]
       }

emp = pd.DataFrame(data=data)
x = emp['name']
y =emp['age']
sal = emp['salary']

x_pos = [i for i, _ in enumerate(x)]

fig, ax = plt.subplots()
rects1 = ax.bar(x_pos, y)

def autolabel(rects):
    i = 0
    for rect in rects:        
        height = rect.get_height()      #get height of every bar
        
        ax.text(rect.get_x() + rect.get_width()/2.,1.05*height,sal[i],ha='center', va='bottom')
        

        i+=1
        
        
autolabel(rects1)

plt.show()






       
         



