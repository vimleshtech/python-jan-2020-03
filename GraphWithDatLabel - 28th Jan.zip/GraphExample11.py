import pandas as pd
import matplotlib.pyplot as plt

data ={'eid':[1,2,3,4,5,6,7,8,9,10],
       'name':['ayush','jatin','divya','mohit','monika','nitisha','raman','gaurav','kshitiz','nidhi'],
       'gender':['male','male','female','male','female','female','male','male','male','female'],
       'age':[21,22,23,41,25,36,47,38,49,41],
       'salary':[10000,20000,30000,40000,50000,60000,70000,80000,90000,100000]
       }


emp = pd.DataFrame(data=data)
print(emp)

###bar   : is also known column

#emp.plot(kind='bar')
#emp.plot(kind='bar',subplots=True)
#emp.plot(kind='bar',subplots=True,layout=(2,2))
#plt.show()

    
##box
#emp.plot(kind='box')
plt.bar(emp['eid'],emp['salary'],color='red')
plt.title('title name',fontsize=14)
plt.xlabel('xAxis name',fontsize=14)
plt.ylabel('yAxis name',fontsize=14)
plt.grid(True)

plt.xticks([i + 0.5 for i, _ in enumerate(emp['name'])], emp['name'])


plt.show()

###line 
#emp.plot(kind='line',subplots=True)
#plt.show()

##pie

###hist
#emp.hist()
#plt.show()

###scatter


